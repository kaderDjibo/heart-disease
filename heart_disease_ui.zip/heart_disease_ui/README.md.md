# Heart Disease Prediction System

## 📌 Project Description
This project is a machine learning–based heart disease prediction system with an interactive Streamlit user interface.  
It predicts the risk of heart disease (Low, Moderate, High) based on patient symptoms, lifestyle, and medical history.

## 🛠️ Technologies Used
- Python
- Streamlit (Frontend)
- Scikit-learn (Machine Learning)
- NumPy, Pandas

## 📂 Project Structure
- app.py – Streamlit application
- heart_disease_model.pkl – Trained ML model
- scaler.pkl – Feature scaler
- requirements.txt – Dependencies

## ▶️ How to Run the Project
1. Install dependencies:
