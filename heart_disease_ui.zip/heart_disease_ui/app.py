import streamlit as st
import numpy as np
import joblib

# ---------- UI STYLING ----------
st.set_page_config(
    page_title="Heart Disease Diagnosis",
    page_icon="❤️",
    layout="centered"
)

st.markdown("""
<style>
.main {
    background-color: #0f172a;
}
h1, h2, h3 {
    color: #e5e7eb;
}
label {
    color: #e5e7eb !important;
}
div[data-testid="stMetric"] {
    background-color: #020617;
    border-radius: 10px;
    padding: 15px;
}
</style>
""", unsafe_allow_html=True)

model = joblib.load("heart_disease_model.pkl")
scaler = joblib.load("scaler.pkl")
st.set_page_config(
    page_title="Heart Disease Diagnosis",
    page_icon="🫀",
    layout="wide"
)
st.title("🫀 Heart Disease Diagnosis Dashboard")
st.markdown("### Clinical Decision Support System")
st.markdown("---")

st.subheader("🧑‍⚕️ Patient Symptoms")
st.caption("Rate each symptom from 0 (Not Present) to 1 (Severe)")

c1, c2 = st.columns(2)

with c1:
    Chest_Pain = st.selectbox("Chest Pain", [0,1])
Shortness_of_Breath = st.selectbox("Shortness of Breath", [0,1])
Fatigue = st.selectbox("Fatigue", [0,1])
Palpitations = st.selectbox("Palpitations", [0,1])
Dizziness = st.selectbox("Dizziness", [0,1])

with c2:
    Swelling = st.selectbox("Swelling", [0,1])
Pain_Arms_Jaw_Back = st.selectbox("Pain Arms", [0,1])
Cold_Sweats_Nausea = st.selectbox("Cold Sweats", [0,1])
High_BP = st.selectbox("High BP", [0,1])
High_Cholesterol = st.selectbox("High Cholesterol", [0,1])

st.markdown("---")

st.subheader("🏃 Lifestyle & Medical History")
st.caption("Patient habits and background risk factors")

m1, m2, m3 = st.columns(3)
with m1:
    Diabetes = st.selectbox("Diabetes", [0,1])
    Smoking = st.selectbox("Smoking", [0,1]) 

with m2:
    Obesity = st.selectbox("Obesity",[0,1])
Sedentary_Lifestyle = st.selectbox("Sedentary History", [0,1])

Family_History = st.selectbox("Family History", [0,1])
Chronic_Stress = st. selectbox("Chronic Stress", [0,1])

st.markdown("---")
st.subheader("👤 Patient Details")

d1, d2 = st.columns(2)

with d1:
    Age = st.slider("Age", 18, 100, 30, key="age")

with d2:
    Gender = st.selectbox("Gender", ["Female", "Male"], key="gender")
    Gender = 1 if Gender == "Male" else 0


st.markdown("---")
st.subheader("🔍 Heart Disease Prediction")

if st.button("💖 Predict Heart Disease Risk"):

    input_data = np.array([[
        Chest_Pain,
        Shortness_of_Breath,
        Fatigue,
        Palpitations,
        Dizziness,
        Swelling,
        Pain_Arms_Jaw_Back,
        Cold_Sweats_Nausea,
        High_BP,
        High_Cholesterol,
        Diabetes,
        Smoking,
        Obesity,
        Sedentary_Lifestyle,
        Family_History,
        Chronic_Stress,
        Age,
        Gender
    ]])

    input_scaled = scaler.transform(input_data)
    prediction = model.predict(input_scaled)[0]

    st.markdown("---")
    st.subheader("🩺 Prediction Result")

    if prediction == 1:
        st.error("🚨 High Risk of Heart Disease detected")
    else:
        st.success("✅ Low Risk of Heart Disease")

    # Scale input
    input_scaled = scaler.transform(input_data)

    # Prediction
    prediction = model.predict(input_scaled)[0]
    probability = model.predict_proba(input_scaled)[0][1]

    # Result display
    if prediction == 1:
        st.error("⚠️ High Risk of Heart Disease Detected")
    else:
        st.success("✅ Low Risk of Heart Disease")

    

if st.button("Predict"):
    data = np.array([[Chest_Pain, Shortness_of_Breath, Fatigue, Palpitations,
                      Dizziness, Swelling, Pain_Arms_Jaw_Back, Cold_Sweats_Nausea,
                      High_BP, High_Cholesterol, Diabetes, Smoking, Obesity,
                      Sedentary_Lifestyle, Family_History, Chronic_Stress,
                      Age, Gender]])

    # ✅ FIX-2 STARTS HERE
    probability = None 

    symptom_score = (
      Chest_Pain +
      Shortness_of_Breath +
      Fatigue +
      Palpitations +
      Dizziness +
      High_BP +
      Diabetes +
      Smoking +
      Obesity
    )

    probability = min(1.0, symptom_score / 9)
        
    st.metric(
       label="📊 Risk Probability",
       value=f"{probability * 100:.2f}%"
    )

    if probability >= 0.6:
        st.error("🔴 High Risk of Heart Disease")
    elif probability >= 0.3:
        st.warning("🟠 Moderate Risk of Heart Disease")
    else:
        st.success("🟢 Low Risk of Heart Disease")